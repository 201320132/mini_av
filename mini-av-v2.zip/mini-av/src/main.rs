// Mini AV - window, UI bridge and command handling.
// The scanning logic lives in engine.rs (pure std, unit-tested).
#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]

mod engine;

use engine::*;
use std::{
    collections::HashMap,
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc, Mutex,
    },
    thread,
};
use tao::{
    dpi::LogicalSize,
    event::{Event as TaoEvent, WindowEvent},
    event_loop::{ControlFlow, EventLoopBuilder, EventLoopProxy},
    window::WindowBuilder,
};
use wry::WebViewBuilder;

enum UserEvent {
    Js(String),
}

struct Item {
    t: Threat,
    state: &'static str,
}

struct App {
    proxy: Mutex<EventLoopProxy<UserEvent>>,
    store: Store,
    items: Mutex<Vec<Item>>,
    cancel: AtomicBool,
    scanning: AtomicBool,
    settings: Mutex<HashMap<String, String>>,
    hashes: HashMap<String, String>,
    excl: Mutex<Vec<String>>,
}

impl App {
    fn js(&self, name: &str, json: &str) {
        let script = format!("window.AV&&window.AV.on({},{})", jstr(name), json);
        if let Ok(p) = self.proxy.lock() {
            let _ = p.send_event(UserEvent::Js(script));
        }
    }
    fn tmsg(&self, key: &str, cls: &str) {
        self.js("tmsg", &format!("{{\"key\":{},\"cls\":{}}}", jstr(key), jstr(cls)));
    }
    fn setting(&self, k: &str, default: &str) -> String {
        self.settings.lock().unwrap().get(k).cloned().unwrap_or_else(|| default.to_string())
    }
    fn set(&self, k: &str, v: &str) {
        let mut s = self.settings.lock().unwrap();
        s.insert(k.to_string(), v.to_string());
        save_kv(&app_dir().join("settings.txt"), &s);
    }
    fn status(&self, id: u64, state: &str, msg: &str) {
        self.js("status", &format!("{{\"ids\":[{id}],\"state\":{},\"msg\":{}}}", jstr(state), jstr(msg)));
    }
    fn send_qlist(&self) {
        let items: Vec<String> = self.store.list().iter().map(|q| q.json()).collect();
        self.js("qlist", &format!("[{}]", items.join(",")));
    }
    fn send_excl(&self) {
        let v: Vec<String> = self.excl.lock().unwrap().iter().map(|s| jstr(s)).collect();
        self.js("excl", &format!("[{}]", v.join(",")));
    }
    fn send_dstatus(&self) {
        let kv = defender_status();
        let body: Vec<String> = kv.iter().map(|(k, v)| format!("{}:{}", jstr(k), jstr(v))).collect();
        self.js("dstatus", &format!("{{{}}}", body.join(",")));
    }

    /// Quarantine / fix the given detections. Returns how many succeeded.
    fn apply(&self, ids: &[u64]) -> usize {
        let mut ok = 0;
        for id in ids {
            let t = {
                let items = self.items.lock().unwrap();
                match items.iter().find(|i| i.t.id == *id && i.state == "found") {
                    Some(i) => i.t.clone(),
                    None => continue,
                }
            };
            let (state, msg): (&'static str, String) = match self.store.quarantine(&t) {
                Ok(m) => {
                    ok += 1;
                    (
                        match m.as_str() {
                            "quarantined" => "quarantined",
                            "restored" => "restored",
                            _ => "fixed",
                        },
                        String::new(),
                    )
                }
                Err(e) => ("failed", e),
            };
            if let Some(i) = self.items.lock().unwrap().iter_mut().find(|i| i.t.id == *id) {
                i.state = state;
            }
            self.status(*id, state, &msg);
        }
        ok
    }
}

fn parse_ids(s: &str) -> Vec<u64> {
    s.split(',').filter_map(|x| x.trim().parse().ok()).collect()
}

fn start_scan(app: &Arc<App>, mode: &str, defender: bool, paths: &str) {
    if app.scanning.swap(true, Ordering::SeqCst) {
        return;
    }
    app.cancel.store(false, Ordering::SeqCst);
    app.items.lock().unwrap().clear();
    let mode = match mode {
        "full" => Mode::Full,
        "custom" => Mode::Custom,
        _ => Mode::Quick,
    };
    let paths: Vec<PathBuf> = if mode == Mode::Custom {
        paths.split('\u{1}').map(str::trim).filter(|p| !p.is_empty()).map(PathBuf::from).collect()
    } else {
        Vec::new()
    };
    let opts = ScanOpts { mode, paths, defender };
    let app = app.clone();
    thread::spawn(move || {
        let excl = app.excl.lock().unwrap().clone();
        let sum = {
            let a = app.clone();
            let mut emit = move |e: Event| match e {
                Event::Phase(p) => a.js("phase", &jstr(p)),
                Event::Progress { scanned, current } => {
                    a.js("progress", &format!("{{\"n\":{},\"cur\":{}}}", scanned, jstr(&current)))
                }
                Event::Found(t) => {
                    a.js("found", &t.json());
                    a.items.lock().unwrap().push(Item { t, state: "found" });
                }
                Event::Log(_) => {}
            };
            run_scan(&opts, &app.cancel, &app.hashes, &excl, &mut emit)
        };
        // quarantine confirmed threats automatically (never the "suspicious" ones)
        let mut auto = 0;
        if app.setting("autoq", "1") == "1" && !sum.cancelled {
            let ids: Vec<u64> = app
                .items
                .lock()
                .unwrap()
                .iter()
                .filter(|i| i.state == "found" && i.t.sev == Sev::High && !i.t.handled)
                .map(|i| i.t.id)
                .collect();
            auto = app.apply(&ids);
        }
        let now = now_secs();
        app.set("last_time", &now.to_string());
        app.set("last_high", &sum.high.to_string());
        app.set("last_medium", &sum.medium.to_string());
        app.js(
            "done",
            &format!(
                "{{\"scanned\":{},\"high\":{},\"medium\":{},\"info\":{},\"cancelled\":{},\"defender\":{},\"time\":{},\"auto\":{}}}",
                sum.scanned, sum.high, sum.medium, sum.info, sum.cancelled, sum.defender_ran, now, auto
            ),
        );
        app.scanning.store(false, Ordering::SeqCst);
    });
}

fn kill_all(app: &Arc<App>) {
    let app = app.clone();
    thread::spawn(move || {
        let todo: Vec<Threat> = app
            .items
            .lock()
            .unwrap()
            .iter()
            .filter(|i| i.state == "found" && i.t.sev == Sev::High && !i.t.handled)
            .map(|i| i.t.clone())
            .collect();
        if todo.iter().any(|t| t.kind == "defender") {
            let _ = powershell("Remove-MpThreat -ErrorAction SilentlyContinue");
        }
        let (mut ok, mut fail) = (0usize, 0usize);
        for t in todo {
            match app.store.destroy(&t) {
                Ok(_) => {
                    ok += 1;
                    if let Some(i) = app.items.lock().unwrap().iter_mut().find(|i| i.t.id == t.id) {
                        i.state = "deleted";
                    }
                    app.status(t.id, "deleted", "");
                }
                Err(e) => {
                    fail += 1;
                    if let Some(i) = app.items.lock().unwrap().iter_mut().find(|i| i.t.id == t.id) {
                        i.state = "failed";
                    }
                    app.status(t.id, "failed", &e);
                }
            }
        }
        let (qo, qf) = app.store.delete_all();
        app.js("killdone", &format!("{{\"ok\":{},\"fail\":{}}}", ok + qo, fail + qf));
    });
}

fn handle(app: &Arc<App>, msg: &str) {
    let mut it = msg.split('\t');
    let cmd = it.next().unwrap_or("");
    let a: Vec<&str> = it.collect();
    let arg = |i: usize| a.get(i).copied().unwrap_or("");
    match cmd {
        "init" => {
            let app = app.clone();
            thread::spawn(move || {
                let drives: Vec<String> = list_drives()
                    .iter()
                    .map(|d| format!("{{\"root\":{},\"removable\":{},\"system\":{}}}", jstr(&d.root), d.removable, d.system))
                    .collect();
                let last = match app.setting("last_time", "").parse::<u64>() {
                    Ok(t) => format!(
                        "{{\"time\":{},\"high\":{},\"medium\":{}}}",
                        t,
                        app.setting("last_high", "0").parse::<u64>().unwrap_or(0),
                        app.setting("last_medium", "0").parse::<u64>().unwrap_or(0)
                    ),
                    Err(_) => "null".into(),
                };
                let excl: Vec<String> = app.excl.lock().unwrap().iter().map(|s| jstr(s)).collect();
                app.js(
                    "init",
                    &format!(
                        "{{\"lang\":{},\"autoq\":{},\"defender\":{},\"admin\":{},\"drives\":[{}],\"last\":{},\"sigs\":{},\"excl\":[{}],\"qcount\":{}}}",
                        jstr(&app.setting("lang", "fa")),
                        app.setting("autoq", "1") == "1",
                        app.setting("defender", "1") == "1",
                        is_admin(),
                        drives.join(","),
                        last,
                        app.hashes.len(),
                        excl.join(","),
                        app.store.list().len()
                    ),
                );
            });
        }
        "dstatus" => {
            let app = app.clone();
            thread::spawn(move || app.send_dstatus());
        }
        "scan" => start_scan(app, arg(0), arg(1) == "1", arg(2)),
        "stop" => {
            app.cancel.store(true, Ordering::SeqCst);
            thread::spawn(defender_cancel);
        }
        "act" => {
            let ids = parse_ids(arg(1));
            match arg(0) {
                "ignore" => {
                    for id in ids {
                        let target = {
                            let mut items = app.items.lock().unwrap();
                            items.iter_mut().find(|i| i.t.id == id).map(|i| {
                                i.state = "ignored";
                                i.t.target.to_lowercase()
                            })
                        };
                        if let Some(tg) = target {
                            let mut ex = app.excl.lock().unwrap();
                            if !ex.contains(&tg) {
                                ex.push(tg);
                            }
                            save_exclusions(&ex);
                            drop(ex);
                            app.status(id, "ignored", "");
                        }
                    }
                    app.send_excl();
                }
                _ => {
                    let app = app.clone();
                    thread::spawn(move || {
                        app.apply(&ids);
                        app.send_qlist();
                    });
                }
            }
        }
        "qlist" => {
            let app = app.clone();
            thread::spawn(move || app.send_qlist());
        }
        "restore" => {
            let (app, id) = (app.clone(), arg(0).to_string());
            thread::spawn(move || {
                match app.store.restore(&id) {
                    Ok(_) => app.js("toast", &format!("{{\"msg\":{},\"cls\":\"ok\"}}", jstr(&tr(&app, "restored_to")))),
                    Err(e) => app.js("toast", &format!("{{\"msg\":{},\"cls\":\"bad\"}}", jstr(&e))),
                }
                app.send_qlist();
            });
        }
        "qdelete" => {
            let (app, id) = (app.clone(), arg(0).to_string());
            thread::spawn(move || {
                let _ = app.store.delete(&id);
                app.send_qlist();
            });
        }
        "killall" => kill_all(app),
        "browse" => {
            let app = app.clone();
            thread::spawn(move || {
                if let Some(p) = browse_folder() {
                    app.js("folder", &jstr(&p));
                }
            });
        }
        "elevate" => {
            let app = app.clone();
            thread::spawn(move || match relaunch_as_admin() {
                Ok(()) => std::process::exit(0),
                Err(e) => app.js("elevate", &format!("{{\"ok\":false,\"msg\":{}}}", jstr(&e))),
            });
        }
        "sigupdate" => {
            let app = app.clone();
            thread::spawn(move || match update_signatures() {
                Ok(()) => app.tmsg("updated", "ok"),
                Err(_) => app.tmsg("failed", "bad"),
            });
        }
        "rtenable" => {
            let app = app.clone();
            thread::spawn(move || {
                match enable_realtime() {
                    Ok(()) => app.tmsg("on", "ok"),
                    Err(_) => app.tmsg("failed", "bad"),
                }
                app.send_dstatus();
            });
        }
        "setopt" => {
            let (k, v) = (arg(0), arg(1));
            if ["lang", "autoq", "defender"].contains(&k) {
                app.set(k, v);
            }
        }
        "settings_info" => {
            let app = app.clone();
            thread::spawn(move || {
                app.send_excl();
                app.js("sigs", &app.hashes.len().to_string());
                app.js("admin", &format!("{{\"admin\":{}}}", is_admin()));
            });
        }
        "rmexcl" => {
            let mut ex = app.excl.lock().unwrap();
            ex.retain(|e| e != arg(0));
            save_exclusions(&ex);
            drop(ex);
            app.send_excl();
        }
        _ => {}
    }
}

/// Tiny server-side translation used only for toasts that originate in Rust.
fn tr(app: &App, key: &str) -> String {
    let fa = app.setting("lang", "fa") == "fa";
    match (key, fa) {
        ("restored_to", true) => "بازیابی شد".into(),
        ("restored_to", false) => "Restored".into(),
        _ => key.into(),
    }
}

fn fatal_box(text: &str) {
    let t = text.replace('\'', "''");
    let _ = powershell(&format!(
        "Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show('{t}','Mini AV')"
    ));
}

fn main() {
    // keep WebView2 data out of the program folder (it may be read-only)
    std::env::set_var("WEBVIEW2_USER_DATA_FOLDER", app_dir().join("webview"));

    let event_loop = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy = event_loop.create_proxy();
    let window = WindowBuilder::new()
        .with_title("Mini AV")
        .with_inner_size(LogicalSize::new(1080.0, 700.0))
        .with_min_inner_size(LogicalSize::new(820.0, 560.0))
        .build(&event_loop)
        .expect("window");

    let app = Arc::new(App {
        proxy: Mutex::new(proxy),
        store: Store::default_store(),
        items: Mutex::new(Vec::new()),
        cancel: AtomicBool::new(false),
        scanning: AtomicBool::new(false),
        settings: Mutex::new(load_kv(&app_dir().join("settings.txt"))),
        hashes: load_signatures(),
        excl: Mutex::new(load_exclusions()),
    });

    let handler_app = app.clone();
    let built = WebViewBuilder::new()
        .with_html(include_str!("../ui/index.html"))
        .with_ipc_handler(move |req: wry::http::Request<String>| handle(&handler_app, req.body()))
        .build(&window);

    let webview = match built {
        Ok(w) => w,
        Err(e) => {
            fatal_box(&format!(
                "Mini AV could not start its window ({e}).\nInstall the Microsoft Edge WebView2 Runtime from https://go.microsoft.com/fwlink/p/?LinkId=2124703 and try again."
            ));
            return;
        }
    };

    event_loop.run(move |event, _, control_flow| {
        *control_flow = ControlFlow::Wait;
        match event {
            TaoEvent::UserEvent(UserEvent::Js(script)) => {
                let _ = webview.evaluate_script(&script);
            }
            TaoEvent::WindowEvent { event: WindowEvent::CloseRequested, .. } => {
                app.cancel.store(true, Ordering::SeqCst);
                *control_flow = ControlFlow::Exit;
            }
            _ => {}
        }
    });
}
