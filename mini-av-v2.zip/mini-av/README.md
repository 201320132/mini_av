# Mini AV / مینی‌AV

Small, free antivirus for Windows 10/11 written in Rust. Dark glass interface (WebView2), Persian and English (RTL/LTR), SVG icons only.

## Build (Windows)
1. Install Rust from https://rustup.rs
2. Double-click `build.bat` -> `mini-av.exe` appears in this folder.
   (Or push the folder to GitHub and download the exe from the Actions tab; see `.github/workflows/build.yml`.)

Needs the Microsoft Edge WebView2 Runtime (already present on Windows 11 and updated Windows 10).

## Features
- Home: protection status, Defender real-time state, definitions age, firewall, quarantine count, last scan.
- Scans: Quick, Full, Custom (any folders/drives). Optionally runs Microsoft Defender at the same time.
- Own detections: fake shortcut (shortcut virus) and recovery of the files it hid, autorun.inf worms, programs disguised as documents/pictures (MZ header), double extensions (`a.pdf.exe`), droppers on USB drives, RECYCLER trick, suspicious startup entries (registry Run keys and Startup folders), suspicious scripts, tampered hosts file, EICAR test file, custom SHA-256 signatures (`signatures.txt`).
- Uses Microsoft Defender for what it does not do itself: engine scan, definitions update, real-time protection switch, threat removal.
- Quarantine: reversible (Restore), obfuscated copies that cannot run, Delete permanently, and **Kill all viruses**.

## Safety design
- Only files reported as detections are ever touched; nothing else is read for modification.
- The Windows folder (except Temp) is never scanned or changed.
- "Suspicious" (yellow) items are never removed automatically and are not touched by Kill all viruses; "Threat" (red) items are.
- Removal goes to quarantine first (unless you press Kill all viruses).
- Junctions/symlinks are never followed.

## Test it safely
Create a text file containing the standard EICAR test string (see eicar.org). Mini AV flags it as `EICAR-Test-File`; it is harmless.

## Limits
This is a lightweight heuristic scanner plus Defender integration. It does not replace a commercial product's cloud intelligence or behavioural engine.
